//Hao yue zheng - 10408948
//Samuel zheng - 10395781

import java.util.LinkedList;

public class HashTableChaining implements HashTable {
    private LinkedList<Entry>[] table;

    public HashTableChaining(int size) {
        this.table = new LinkedList[size];
        for (int i = 0; i < size; i++) {
            table[i] = new LinkedList<>();
        }
    }

    private int hash(int key) {
        return Math.abs(key * 31) % table.length;
    }

    @Override
    public String search(int key) {
        int index = hash(key);
        for (Entry entry : table[index]) {
            if (entry.key == key) {
                return entry.value;
            }
        }
        return null;
    }

    @Override
    public String insert(int key, String value) {
        int index = hash(key);
        for (Entry entry : table[index]) {
            if (entry.key == key) {
                entry.value = value;
                return "valor da chave atualizado";
            }
        }
        table[index].add(new Entry(key, value));
        return "chave-valor inserido";
    }

    @Override
    public boolean delete(int key) {
        int index = hash(key);
        for (Entry entry : table[index]) {
            if (entry.key == key) {
                return table[index].remove(entry);
            }
        }
        return false;
    }

    public void printTable() {
        System.out.println("Estado atual da HashTableChaining:");
        for (int i = 0; i < table.length; i++) {
            LinkedList<Entry> list = table[i];
            if (list.isEmpty()) {
                System.out.println("Slot " + i + ": Vazio");
            } else {
                System.out.print("Slot " + i + ": ");
                for (Entry entry : list) {
                    System.out.print("[Chave = " + entry.key + ", Valor = " + entry.value + "] ");
                }
                System.out.println();
            }
        }
    }

    private static class Entry {
        int key;
        String value;

        Entry(int key, String value) {
            this.key = key;
            this.value = value;
        }
    }
}
