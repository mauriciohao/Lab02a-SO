//Hao yue zheng - 10408948
//Samuel zheng - 10395781

public interface HashTable {
    // Busca um valor com base na chave fornecida e retorna o valor se encontrado
    String search(int key);
    
    // Insere um par chave-valor na tabela hash e retorna uma mensagem sobre o sucesso da operação
    String insert(int key, String value);
    
    // Remove um par chave-valor com base na chave fornecida e retorna true se a remoção foi bem-sucedida
    boolean delete(int key);
}
