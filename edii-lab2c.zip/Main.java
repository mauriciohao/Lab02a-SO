//Hao yue zheng - 10408948
//Samuel zheng - 10395781

public class Main {
    public static void main(String[] args) {
        // Criando tabelas hash com tamanho inicial pequeno para facilitar testes
        HashTable hashTableOA = new HashTableOA(5); // Endereçamento aberto
        HashTable hashTableChaining = new HashTableChaining(5); // Encadeamento

        // Definindo chaves e valores para inserção
        int[] keys = {1, 2, 3, 4, 5, 6, 7};
        String[] values = {"Ferrari F8", "Lamborghini Huracan", "Porsche 911", "Bentley Continental", "Aston Martin DB11", "Rolls Royce Phantom", "Maserati GranTurismo"};

        // Realizando testes com HashTable de Endereçamento Aberto
        System.out.println("Testes com HashTable de Endereçamento Aberto:");
        performTests(hashTableOA, keys, values);

        // Realizando testes com HashTable de Encadeamento
        System.out.println("\nTestes com HashTable de Encadeamento:");
        performTests(hashTableChaining, keys, values);
    }

    private static void performTests(HashTable hashTable, int[] keys, String[] values) {
        // Testando inserções
        for (int i = 0; i < keys.length; i++) {
            String response = hashTable.insert(keys[i], values[i]);
            System.out.println("Inserção: Chave = " + keys[i] + ", Valor = " + values[i] + " - Resultado: " + response);
        }

        // Testando a busca de chaves
        System.out.println("\nBuscas:");
        for (int key : keys) {
            String result = hashTable.search(key);
            System.out.println("Busca: Chave = " + key + " - Resultado: " + (result == null ? "não encontrado" : result));
        }

        // Testando a tentativa de remoção de uma chave inexistente
        System.out.println("\nTentativa de remoção de chave inexistente (69):");
        boolean deleteResult = hashTable.delete(69);
        System.out.println("Remoção: Chave = 69 - Resultado: " + (deleteResult ? "true" : "falso"));

        // Testando a inserção de uma chave adicional para verificar o comportamento quando a tabela está cheia
        System.out.println("\nTestando a inserção quando a tabela está potencialmente cheia:");
        String additionalInsertResponse = hashTable.insert(69, "Teste Tabela Cheia");
        System.out.println("Inserção: Chave = 69, Valor = Buggatti veyron - Resultado: " + additionalInsertResponse);

        // Estado final da tabela hash
        if (hashTable instanceof HashTableOA) {
            ((HashTableOA) hashTable).printTable();
        } else if (hashTable instanceof HashTableChaining) {
            ((HashTableChaining) hashTable).printTable();
        }
    }
}
