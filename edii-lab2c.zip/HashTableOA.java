//Hao yue zheng - 10408948
//Samuel zheng - 10395781 


public class HashTableOA implements HashTable {
    private static class Entry {
        int key;
        String value;
        boolean isActive;

        Entry(int key, String value) {
            this.key = key;
            this.value = value;
            this.isActive = true;
        }
    }

    private Entry[] table;
    private int size;
    private int count;  // Contador para rastrear o número de elementos ativos

    public HashTableOA(int size) {
        this.size = size;
        this.table = new Entry[size];
        this.count = 0;
    }

    private int hash(int key) {
        return key % size;
    }

    @Override
    public String search(int key) {
        int index = hash(key);
        while (table[index] != null) {
            if (table[index].key == key && table[index].isActive) {
                return table[index].value;
            }
            index = (index + 1) % size;
        }
        return null;
    }

    @Override
    public String insert(int key, String value) {
        if (count >= size * 0.75) {  // Fator de carga para iniciar o redimensionamento
            resize();
        }
        int index = hash(key);
        int startIndex = index;
        do {
            if (table[index] == null || !table[index].isActive) {
                table[index] = new Entry(key, value);
                count++;
                return "chave-valor inserido";
            }
            if (table[index].key == key && table[index].isActive) {
                table[index].value = value;
                return "valor da chave atualizado";
            }
            index = (index + 1) % size;
            if (index == startIndex) break;
        } while (index != startIndex);

        return "erro ao inserir chave-valor";
    }

    @Override
    public boolean delete(int key) {
        int index = hash(key);
        int startIndex = index;
        do {
            if (table[index] != null && table[index].isActive && table[index].key == key) {
                table[index].isActive = false;
                count--;
                return true;
            }
            index = (index + 1) % size;
            if (index == startIndex) break;
        } while (index != startIndex);
        return false;
    }

    private void resize() {
        int newSize = size * 2;
        Entry[] newTable = new Entry[newSize];
        for (int i = 0; i < size; i++) {
            if (table[i] != null && table[i].isActive) {
                Entry oldEntry = table[i];
                int index = oldEntry.key % newSize;
                while (newTable[index] != null) {
                    index = (index + 1) % newSize;
                }
                newTable[index] = new Entry(oldEntry.key, oldEntry.value);
            }
        }
        table = newTable;
        size = newSize;
    }

    public void printTable() {
        System.out.println("Estado atual da HashTableOA:");
        for (int i = 0; i < table.length; i++) {
            Entry entry = table[i];
            if (entry != null && entry.isActive) {
                System.out.println("Slot " + i + ": Chave = " + entry.key + ", Valor = " + entry.value + ", Ativo");
            } else if (entry != null) {
                System.out.println("Slot " + i + ": Chave = " + entry.key + ", Valor = " + entry.value + ", Inativo");
            } else {
                System.out.println("Slot " + i + ": Vazio");
            }
        }
    }
}
